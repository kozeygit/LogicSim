# from flask import Flask
# app = Flask(__name__)

# @app.route('/')
# def hello_world():
#   return 'Hello, World!'

# @app.route('/name/')
# def hello_name():
#   return str(hello_world() + 'n')

# @app.route("/name/<string:name>/")
# def getMember(name):
#     return name


# if __name__ == '__main__':
#   app.run()

from Logic_Gates import *
import pygame
pygame.init()

HEIGHT, WIDTH = 400,400
WHITE = (255,255,255)
BLACK = (0,0,0)
RED = (255,0,0)
GREEN = (0,255,0)
BLUE = (0,0,255)
screen = pygame.display.set_mode((HEIGHT, WIDTH))
clock = pygame.time.Clock()
FPS = 60
gates = {
  'AND':And_Gate,
  'OR' :Or_Gate,
  'XOR':Xor_Gate,
  'NOT':Not_Gate,
  'SWITCH':Switch
}

class Box:
  def __init__(self, gateType, height=50, width=50, x=50, y=50, colour=BLACK):
    self.colour = colour
    self.size = (width,height)
    self.pos = (x,y)
    self.surface = pygame.Surface(self.size)
    self.gate = gates[gateType]()
  
  def blit(self):
    pygame.draw.rect(screen, self.colour, pygame.Rect(self.pos, self.size))
    self.displayOutput()

  def displayOutput(self):
    out = self.gate.getOutput()
    print(str(out))

class Toolbar:
  def __init__(self):
    self.x = 0
    self.y = 0
    self.width = WIDTH
    self.height = 80
    self.size = (self.width, self.height)
    self.surface = pygame.Surface(self.size)

  def blit(self):
    pygame.draw.rect(screen, self.colour, pygame.Rect(self.pos, self.size))
    self.displayOutput()

s = Box('SWITCH')
s2 = Box('SWITCH', y=150)
a = Box('AND', x=150)
o = Box('NOT', x=250)

run = True
while run:
  clock.tick()
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      run = False
  screen.fill(WHITE)
  s.blit()
  s2.blit()
  a.blit()
  o.blit()
  pygame.display.update()


pygame.quit()





s1 = Switch()
s2 = Switch()
a1 = And_Gate()
n1 = Not_Gate()
o1 = Output()

a1.connectNode(1, s1)
a1.connectNode(2, s2)

print(a1.getOutput())

s1.flip()
print(a1.getOutput())

s2.flip()
print(a1.getOutput())

n1.connectNode(1, a1)

print(n1.getOutput())






